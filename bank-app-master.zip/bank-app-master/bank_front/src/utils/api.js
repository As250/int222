export const API_URL = 'http://localhost:4000/api';
//export const API_URL = 'https://bank-appdk.herokuapp.com/api';
