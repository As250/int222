import React from 'react';
import logoImg from '../../assets/images/logo.png';

const logo = () => <img src={logoImg} alt="Bank app logo"/>;

export default logo;
