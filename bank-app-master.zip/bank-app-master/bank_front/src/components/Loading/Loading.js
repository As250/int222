import React from 'react';
import './Loading.scss';

const loading = () => <div className="loading-bar"></div>;


export default loading;
