import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';

const spinner = () => <CircularProgress style={{color:"rgba(10,171,252,1)"}} />;

export default spinner;
