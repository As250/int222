import React from 'react';
import './NotFound.scss'

const notFound = () => <div className="NotFound"><h1>404 - not found page</h1></div>;

export default notFound;
